package net.fedorm.mod;

import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fedorm.mod.block.ModBlocks;
import net.fedorm.mod.item.ModItemGroups;
import net.fedorm.mod.item.ModItems;
import net.fedorm.mod.world.gen.ModWorldGeneration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlocksAndResources implements ModInitializer {
	public static final String MOD_ID = "blocks_and_resources";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModItemGroups.registerItemGroups();
		ModItems.registerModItems();
		ModBlocks.registerModBlocks();
		ModWorldGeneration.generateModWorldGen();

		FuelRegistry.INSTANCE.add(ModItems.STAR, 10000);
	}
}