package net.fedorm.mod;

import net.fabricmc.api.ClientModInitializer;

public class BlocksAndResourcesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
