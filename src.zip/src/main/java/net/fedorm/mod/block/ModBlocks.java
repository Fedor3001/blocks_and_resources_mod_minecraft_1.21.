package net.fedorm.mod.block;

import net.fedorm.mod.BlocksAndResources;
import net.fedorm.mod.block.CustomBlocks.RefrigerationUnit;
import net.fedorm.mod.block.CustomBlocks.YellowCrystalLampBlock;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public class ModBlocks {

    public static final Block STONE_YELLOW_CRYSTAL_ORE = registerBlock("stone_yellow_crystal_ore", new Block(AbstractBlock.Settings.create()
            .strength(3f).requiresTool().sounds(BlockSoundGroup.STONE)));
    public static final Block DEEPSLATE_YELLOW_CRYSTAL_ORE = registerBlock("deepslate_yellow_crystal_ore", new Block(AbstractBlock.Settings.create()
            .strength(4f).requiresTool().sounds(BlockSoundGroup.DEEPSLATE)));
    public static final Block YELLOW_CRYSTAL_BLOCK = registerBlock("yellow_crystal_block", new Block(AbstractBlock.Settings.create()
            .strength(3f).requiresTool()));
    public static final Block RAW_YELLOW_CRYSTAL_BLOCK = registerBlock("raw_yellow_crystal_block", new Block(AbstractBlock.Settings.create()
            .strength(3f).requiresTool()));
    public static final Block IMPERIAL_YELLOW_CRYSTAL_BLOCK = registerBlock("imperial_yellow_crystal_block", new Block(AbstractBlock.Settings.create()
            .strength(30f).requiresTool()));
    public static final Block REFRIGERATION_UNIT = registerBlock("refrigeration_unit", new RefrigerationUnit(AbstractBlock.Settings.create().strength(7f).requiresTool()
            .sounds(BlockSoundGroup.GLASS)));
    public static final Block YELLOW_CRYSTAL_STAIRS = registerBlock("yellow_crystal_stairs", new StairsBlock(ModBlocks.YELLOW_CRYSTAL_BLOCK.getDefaultState(),
            AbstractBlock.Settings.create().strength(2f)));
    public static final Block YELLOW_CRYSTAL_SLAB = registerBlock("yellow_crystal_slab", new SlabBlock(AbstractBlock.Settings.create().strength(2f)));
    public static final Block YELLOW_CRYTAL_TRAPDOOR = registerBlock("yellow_crystal_trapdoor", new TrapdoorBlock(BlockSetType.OAK, AbstractBlock.Settings.create()
            .strength(2f).requiresTool()));
    public static final Block YELLOW_CRYSTAL_DOOR = registerBlock("yellow_crystal_door", new DoorBlock(BlockSetType.OAK, AbstractBlock.Settings.create()
            .strength(2f).requiresTool()));
    public static final Block YELLOW_CRYSTAL_LAMP = registerBlock("yellow_crystal_lamp", new YellowCrystalLampBlock(AbstractBlock.Settings.create()
            .strength(2f).requiresTool().luminance(state -> state.get(YellowCrystalLampBlock.CLICKED) ? 15 : 0)));
    public static final Block YELLOW_CRYSTAL_BUTTON = registerBlock("yellow_crystal_button", new ButtonBlock(BlockSetType.STONE, 10, AbstractBlock.Settings.create()
            .strength(1f)));
    public static final Block YELLOW_CRYSTAL_FENCE = registerBlock("yellow_crystal_fence", new FenceBlock(AbstractBlock.Settings.create()
            .strength(2f).requiresTool()));
    public static final Block SALT_BLOCK = registerBlock("salt_block", new Block(AbstractBlock.Settings.create().strength(2f).requiresTool()));


    private static Block registerBlock(String name, Block block){
        registerBlockItem(name, block);
        return Registry.register(Registries.BLOCK, Identifier.of(BlocksAndResources.MOD_ID, name), block);
    }

    private static void registerBlockItem(String name, Block block){
        Registry.register(Registries.ITEM, Identifier.of(BlocksAndResources.MOD_ID, name),
                new BlockItem(block, new Item.Settings()));
    }

    public static void registerModBlocks(){
        BlocksAndResources.LOGGER.info("Registering Mod Blocks for "+ BlocksAndResources.MOD_ID);
    }
}
