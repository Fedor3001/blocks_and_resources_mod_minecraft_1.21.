package net.fedorm.mod.block.CustomBlocks;

import net.fedorm.mod.item.ModItems;
import net.fedorm.mod.util.ModTags;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class RefrigerationUnit extends Block {
    public RefrigerationUnit(Settings settings) {
        super(settings);
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (entity instanceof LivingEntity livingEntity) {
            // Замораживаем сущность
            livingEntity.setFrozenTicks(200); // Устанавливаем заморозку на 10 секунд
            livingEntity.setHealth(livingEntity.getHealth()); // Обновляем здоровье для отображения синих сердец

            // Наносим урон, пока сущность на блоке
            if (world instanceof ServerWorld serverWorld) {
                serverWorld.getServer().execute(() -> {
                    livingEntity.damage(livingEntity.getDamageSources().freeze(), 1.0F); // Наносим урон
                });
            }
        }
        if (entity instanceof ItemEntity itemEntity){
            if (isValidItem(itemEntity.getStack())){
                itemEntity.setStack(new ItemStack(ModItems.CHOCOLATE, itemEntity.getStack().getCount()));
            }
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    private boolean isValidItem(ItemStack stack) {
        return stack.isIn(ModTags.Items.FREEZE_ITEMS);
    }

    // Метод для проверки, находится ли сущность на блоке
    public static boolean isEntityOnBlock(Entity entity, BlockPos pos) {
        return entity.getBlockPos().equals(pos);
    }
}
