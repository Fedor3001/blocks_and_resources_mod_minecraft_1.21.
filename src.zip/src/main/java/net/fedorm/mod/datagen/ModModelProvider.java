package net.fedorm.mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.fedorm.mod.block.CustomBlocks.YellowCrystalLampBlock;
import net.fedorm.mod.block.ModBlocks;
import net.fedorm.mod.item.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.data.client.*;
import net.minecraft.item.ArmorItem;
import net.minecraft.util.Identifier;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockStateModelGenerator blockStateModelGenerator) {
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.STONE_YELLOW_CRYSTAL_ORE);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.IMPERIAL_YELLOW_CRYSTAL_BLOCK);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.REFRIGERATION_UNIT);
        blockStateModelGenerator.registerTrapdoor(ModBlocks.YELLOW_CRYTAL_TRAPDOOR);
        blockStateModelGenerator.registerSimpleCubeAll(ModBlocks.SALT_BLOCK);
        BlockStateModelGenerator.BlockTexturePool yellowCrystalPool = blockStateModelGenerator.registerCubeAllModelTexturePool(ModBlocks.YELLOW_CRYSTAL_BLOCK);

        yellowCrystalPool.fence(ModBlocks.YELLOW_CRYSTAL_FENCE);
        yellowCrystalPool.button(ModBlocks.YELLOW_CRYSTAL_BUTTON);

        blockStateModelGenerator.registerDoor(ModBlocks.YELLOW_CRYSTAL_DOOR);

        yellowCrystalPool.stairs(ModBlocks.YELLOW_CRYSTAL_STAIRS);
        yellowCrystalPool.slab(ModBlocks.YELLOW_CRYSTAL_SLAB);


        Identifier lampOffIdentifier = TexturedModel.CUBE_ALL.upload(ModBlocks.YELLOW_CRYSTAL_LAMP, blockStateModelGenerator.modelCollector);
        Identifier lampOnIdentifier = blockStateModelGenerator.createSubModel(ModBlocks.YELLOW_CRYSTAL_LAMP, "_on", Models.CUBE_ALL, TextureMap::all);
        blockStateModelGenerator.blockStateCollector.accept(VariantsBlockStateSupplier.create(ModBlocks.YELLOW_CRYSTAL_LAMP)
                .coordinate(BlockStateModelGenerator.createBooleanModelMap(YellowCrystalLampBlock.CLICKED, lampOnIdentifier, lampOffIdentifier)));
    }

    @Override
    public void generateItemModels(ItemModelGenerator itemModelGenerator) {
        itemModelGenerator.register(ModItems.YELLOW_KRYSTAL, Models.GENERATED);
        itemModelGenerator.register(ModItems.RAW_YELLOW_CRYSTAL, Models.GENERATED);
        itemModelGenerator.register(ModItems.CHOCOLATE, Models.GENERATED);
        itemModelGenerator.register(ModItems.BROCCOLI, Models.GENERATED);
        itemModelGenerator.register(ModItems.TOMATO, Models.GENERATED);
        itemModelGenerator.register(ModItems.CUCUMBER, Models.GENERATED);
        itemModelGenerator.register(ModItems.CHOCOLATE_DRINK, Models.GENERATED);
        itemModelGenerator.register(ModItems.COFFEE, Models.GENERATED);
        itemModelGenerator.register(ModItems.POMEGRANATE, Models.GENERATED);
        itemModelGenerator.register(ModItems.SWEET_PEPER, Models.GENERATED);
        itemModelGenerator.register(ModItems.SALT_CRYSTAL, Models.GENERATED);
        itemModelGenerator.register(ModItems.PILE_OF_SALT, Models.GENERATED);
        itemModelGenerator.register(ModItems.EMPTY_JAR, Models.GENERATED);
        itemModelGenerator.register(ModItems.JAR_OF_PICKLED_TOMATOES, Models.GENERATED);
        itemModelGenerator.register(ModItems.JAR_OF_PICKLES, Models.GENERATED);
        itemModelGenerator.register(ModItems.STAR, Models.GENERATED);

        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_AXE, Models.HANDHELD);
        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_PICKAXE, Models.HANDHELD);
        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_SWORD, Models.HANDHELD);
        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_SHOVEL, Models.HANDHELD);
        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_HOE, Models.HANDHELD);

        itemModelGenerator.registerArmor(((ArmorItem) ModItems.YELLOW_CRYSTAL_BOOTS));
        itemModelGenerator.registerArmor(((ArmorItem) ModItems.YELLOW_CRYSTAL_HELMET));
        itemModelGenerator.registerArmor(((ArmorItem) ModItems.YELLOW_CRYSTAL_CHESTPLATE));
        itemModelGenerator.registerArmor(((ArmorItem) ModItems.YELLOW_CRYSTAL_LEGGINGS));

        itemModelGenerator.register(ModItems.YELLOW_CRYSTAL_HORSE_ARMOR, Models.GENERATED);
    }

}
