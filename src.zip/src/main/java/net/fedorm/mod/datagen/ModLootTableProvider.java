package net.fedorm.mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fedorm.mod.block.ModBlocks;
import net.fedorm.mod.item.ModDrinks;
import net.fedorm.mod.item.ModItems;
import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LeafEntry;
import net.minecraft.loot.function.ApplyBonusLootFunction;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;

import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<RegistryWrapper.WrapperLookup> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void generate() {
        addDrop(ModBlocks.YELLOW_CRYSTAL_BLOCK);
        addDrop(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK);
        addDrop(ModBlocks.IMPERIAL_YELLOW_CRYSTAL_BLOCK);
        addDrop(ModBlocks.REFRIGERATION_UNIT);
        addDrop(ModBlocks.YELLOW_CRYSTAL_STAIRS);
        addDrop(ModBlocks.YELLOW_CRYTAL_TRAPDOOR);
        addDrop(ModBlocks.YELLOW_CRYSTAL_DOOR, doorDrops(ModBlocks.YELLOW_CRYSTAL_DOOR));
        addDrop(ModBlocks.YELLOW_CRYSTAL_BUTTON);
        addDrop(ModBlocks.YELLOW_CRYSTAL_SLAB);
        addDrop(ModBlocks.YELLOW_CRYSTAL_FENCE);
        addDrop(ModBlocks.SALT_BLOCK);

        addDrop(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE, multipleOreDrops(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE, ModItems.RAW_YELLOW_CRYSTAL, 3, 5));
        addDrop(ModBlocks.STONE_YELLOW_CRYSTAL_ORE, multipleOreDrops(ModBlocks.STONE_YELLOW_CRYSTAL_ORE, ModItems.RAW_YELLOW_CRYSTAL, 3, 5));

    }

    public LootTable.Builder multipleOreDrops(Block drop, Item item, float minDrops, float maxDrops) {
        RegistryWrapper.Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
        return this.dropsWithSilkTouch(drop, this.applyExplosionDecay(drop, ((LeafEntry.Builder<?>)
                ItemEntry.builder(item).apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(minDrops, maxDrops))))
                .apply(ApplyBonusLootFunction.oreDrops(impl.getOrThrow(Enchantments.FORTUNE)))));
    }


}
