package net.fedorm.mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fedorm.mod.item.ModItems;
import net.fedorm.mod.util.ModTags;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.ItemTags;

import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup wrapperLookup) {
        getOrCreateTagBuilder(ModTags.Items.FREEZE_ITEMS)
                .add(ModItems.CHOCOLATE_DRINK);
        getOrCreateTagBuilder(ItemTags.SWORDS)
                .add(ModItems.YELLOW_CRYSTAL_SWORD);
        getOrCreateTagBuilder(ItemTags.PICKAXES)
                .add(ModItems.YELLOW_CRYSTAL_PICKAXE);
        getOrCreateTagBuilder(ItemTags.AXES)
                .add(ModItems.YELLOW_CRYSTAL_AXE);
        getOrCreateTagBuilder(ItemTags.HOES)
                .add(ModItems.YELLOW_CRYSTAL_HOE);
        getOrCreateTagBuilder(ItemTags.SHOVELS)
                .add(ModItems.YELLOW_CRYSTAL_SHOVEL);

        getOrCreateTagBuilder(ItemTags.TRIMMABLE_ARMOR)
                .add(ModItems.YELLOW_CRYSTAL_BOOTS)
                .add(ModItems.YELLOW_CRYSTAL_HELMET)
                .add(ModItems.YELLOW_CRYSTAL_CHESTPLATE)
                .add(ModItems.YELLOW_CRYSTAL_LEGGINGS);

        getOrCreateTagBuilder(ItemTags.TRIM_MATERIALS)
                .add(ModItems.YELLOW_KRYSTAL);
    }
}
