package net.fedorm.mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fedorm.mod.block.ModBlocks;
import net.fedorm.mod.util.ModTags;
import net.minecraft.block.Block;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;

import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(RegistryWrapper.WrapperLookup wrapperLookup) {
        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
                .add(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.STONE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.IMPERIAL_YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.REFRIGERATION_UNIT)
                .add(ModBlocks.YELLOW_CRYSTAL_SLAB)
                .add(ModBlocks.YELLOW_CRYSTAL_STAIRS)
                .add(ModBlocks.YELLOW_CRYSTAL_DOOR)
                .add(ModBlocks.YELLOW_CRYTAL_TRAPDOOR)
                .add(ModBlocks.YELLOW_CRYSTAL_LAMP)
                .add(ModBlocks.YELLOW_CRYSTAL_FENCE)
                .add(ModBlocks.YELLOW_CRYSTAL_LAMP)
                .add(ModBlocks.SALT_BLOCK);

        getOrCreateTagBuilder(BlockTags.NEEDS_DIAMOND_TOOL)
                .add(ModBlocks.YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.STONE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.IMPERIAL_YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.REFRIGERATION_UNIT)
                .add(ModBlocks.YELLOW_CRYSTAL_SLAB)
                .add(ModBlocks.YELLOW_CRYSTAL_STAIRS)
                .add(ModBlocks.YELLOW_CRYSTAL_DOOR)
                .add(ModBlocks.YELLOW_CRYTAL_TRAPDOOR)
                .add(ModBlocks.YELLOW_CRYSTAL_LAMP)
                .add(ModBlocks.YELLOW_CRYSTAL_FENCE)
                .add(ModBlocks.SALT_BLOCK);

        getOrCreateTagBuilder(BlockTags.NEEDS_IRON_TOOL)
                .add(ModBlocks.YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK)
                .add(ModBlocks.STONE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE)
                .add(ModBlocks.YELLOW_CRYSTAL_SLAB)
                .add(ModBlocks.YELLOW_CRYSTAL_STAIRS)
                .add(ModBlocks.YELLOW_CRYSTAL_DOOR)
                .add(ModBlocks.YELLOW_CRYTAL_TRAPDOOR)
                .add(ModBlocks.YELLOW_CRYSTAL_LAMP)
                .add(ModBlocks.YELLOW_CRYSTAL_FENCE)
                .add(ModBlocks.SALT_BLOCK);

        getOrCreateTagBuilder(ModTags.Blocks.NEEDS_YELLOW_CRYSTAL_TOOL)
                .addTag(BlockTags.NEEDS_DIAMOND_TOOL);
        getOrCreateTagBuilder(BlockTags.FENCES)
                .add(ModBlocks.YELLOW_CRYSTAL_FENCE);
    }
}

