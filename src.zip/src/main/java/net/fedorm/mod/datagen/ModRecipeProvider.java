package net.fedorm.mod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fedorm.mod.block.ModBlocks;
import net.fedorm.mod.item.ModItems;
import net.minecraft.data.server.recipe.RecipeExporter;
import net.minecraft.item.ItemConvertible;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.registry.RegistryWrapper;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void generate(RecipeExporter exporter) {
        List<ItemConvertible> YELLOW_CRYSTAL_SMELTABLES = List.of(ModItems.RAW_YELLOW_CRYSTAL, ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE,
                ModBlocks.STONE_YELLOW_CRYSTAL_ORE);

        offerSmelting(exporter, YELLOW_CRYSTAL_SMELTABLES, RecipeCategory.MISC, ModItems.YELLOW_KRYSTAL, 0.25f, 200, "yellow_crystal");
        offerBlasting(exporter, YELLOW_CRYSTAL_SMELTABLES, RecipeCategory.MISC, ModItems.YELLOW_KRYSTAL, 0.25f, 100, "yellow_crystal");

        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYSTAL_BUTTON, ModBlocks.YELLOW_CRYSTAL_BLOCK, 1);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYSTAL_DOOR, ModBlocks.YELLOW_CRYSTAL_BLOCK, 1);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYSTAL_SLAB, ModBlocks.YELLOW_CRYSTAL_BLOCK, 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYSTAL_STAIRS, ModBlocks.YELLOW_CRYSTAL_BLOCK, 1);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYTAL_TRAPDOOR, ModBlocks.YELLOW_CRYSTAL_BLOCK, 1);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, ModBlocks.YELLOW_CRYSTAL_FENCE, ModBlocks.YELLOW_CRYSTAL_BLOCK, 1);
    }
}
