package net.fedorm.mod.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fedorm.mod.BlocksAndResources;
import net.fedorm.mod.block.ModBlocks;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroups {
    public static void registerItemGroups(){
        BlocksAndResources.LOGGER.info("Registering Item Groups for "+BlocksAndResources.MOD_ID);
    }

    public static final ItemGroup NEW_BLOCKS_AND_RESOURCES = Registry.register(Registries.ITEM_GROUP,
            Identifier.of(BlocksAndResources.MOD_ID, "new_blocks_and_resources_group"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(ModItems.YELLOW_KRYSTAL))
                    .displayName(Text.translatable("itemgroup.blocks_and_resources.new_items"))
                    .entries((displayContext, entries) -> {
                        entries.add(ModItems.YELLOW_KRYSTAL);
                        entries.add(ModItems.RAW_YELLOW_CRYSTAL);
                        entries.add(ModBlocks.STONE_YELLOW_CRYSTAL_ORE);
                        entries.add(ModBlocks.DEEPSLATE_YELLOW_CRYSTAL_ORE);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_BLOCK);
                        entries.add(ModBlocks.RAW_YELLOW_CRYSTAL_BLOCK);
                        entries.add(ModBlocks.IMPERIAL_YELLOW_CRYSTAL_BLOCK);
                        entries.add(ModItems.BROCCOLI);
                        entries.add(ModItems.TOMATO);
                        entries.add(ModItems.CUCUMBER);
                        entries.add(ModItems.SWEET_PEPER);
                        entries.add(ModBlocks.REFRIGERATION_UNIT);
                        entries.add(ModItems.POMEGRANATE);
                        entries.add(ModItems.COFFEE);
                        entries.add(ModItems.CHOCOLATE_DRINK);
                        entries.add(ModItems.CHOCOLATE);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_SLAB);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_STAIRS);
                        entries.add(ModBlocks.YELLOW_CRYTAL_TRAPDOOR);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_LAMP);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_DOOR);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_BUTTON);
                        entries.add(ModItems.YELLOW_CRYSTAL_AXE);
                        entries.add(ModItems.YELLOW_CRYSTAL_SWORD);
                        entries.add(ModItems.YELLOW_CRYSTAL_PICKAXE);
                        entries.add(ModItems.YELLOW_CRYSTAL_HOE);
                        entries.add(ModItems.YELLOW_CRYSTAL_SHOVEL);
                        entries.add(ModItems.YELLOW_CRYSTAL_BOOTS);
                        entries.add(ModItems.YELLOW_CRYSTAL_LEGGINGS);
                        entries.add(ModItems.YELLOW_CRYSTAL_CHESTPLATE);
                        entries.add(ModItems.YELLOW_CRYSTAL_HELMET);
                        entries.add(ModItems.SALT_CRYSTAL);
                        entries.add(ModItems.PILE_OF_SALT);
                        entries.add(ModItems.EMPTY_JAR);
                        entries.add(ModItems.JAR_OF_PICKLES);
                        entries.add(ModItems.JAR_OF_PICKLED_TOMATOES);
                        entries.add(ModItems.STAR);
                        entries.add(ModItems.YELLOW_CRYSTAL_HORSE_ARMOR);
                        entries.add(ModBlocks.YELLOW_CRYSTAL_FENCE);
                        entries.add(ModBlocks.SALT_BLOCK);


                    }).build()
            );

}
