package net.fedorm.mod.item;

import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.UseAction;

public class ModDrinks extends Item {

    public static final FoodComponent COFFEE = new FoodComponent.Builder().nutrition(6).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 2400, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 2400, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.HASTE, 2400, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 2400, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 2400, 2), 1f)
            .build();
    public static final FoodComponent CHOCOLATE_DRINK = new FoodComponent.Builder().nutrition(2).saturationModifier(0.25f).build();
    public static final FoodComponent JAR_OF_PICKLES = new FoodComponent.Builder().nutrition(10).saturationModifier(0.5f)
            .statusEffect(new StatusEffectInstance(StatusEffects.HASTE, 120*20, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120*20, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 120*20, 2), 1f)
            .build();
    public static final FoodComponent JAR_OF_PICKLED_TOMATOES = new FoodComponent.Builder().nutrition(10).saturationModifier(0.5f)
            .statusEffect(new StatusEffectInstance(StatusEffects.HASTE, 120*20, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120*20, 2), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 120*20, 2), 1f)
            .build();

    public ModDrinks(Settings settings) {
        super(settings);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }
}
