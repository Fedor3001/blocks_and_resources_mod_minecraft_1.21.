package net.fedorm.mod.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fedorm.mod.BlocksAndResources;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    public static final Item YELLOW_KRYSTAL = registerItem("yellow_krystal", new Item(new Item.Settings()));
    public static final Item RAW_YELLOW_CRYSTAL = registerItem("raw_yellow_crystal", new Item(new Item.Settings()));
    public static final Item EMPTY_JAR = registerItem("empty_jar", new Item(new Item.Settings().maxCount(16)));
    public static final Item STAR = registerItem("star", new Item(new Item.Settings()));

    public static final Item BROCCOLI = registerItem("broccoli", new Item(new Item.Settings().food(ModFood.BROCCOLI)));
    public static final Item TOMATO = registerItem("tomato", new Item(new Item.Settings().food(ModFood.TOMATO)));
    public static final Item CUCUMBER = registerItem("cucumber", new Item(new Item.Settings().food(ModFood.CUCUMBER)));
    public static final Item SWEET_PEPER = registerItem("sweet_peper", new Item(new Item.Settings().food(ModFood.SWEET_PEPER)));
    public static final Item POMEGRANATE = registerItem("pomegranate", new Item(new Item.Settings().food(ModFood.POMEGRANATE)));
    public static final Item CHOCOLATE = registerItem("chocolate", new Item(new Item.Settings().food(ModFood.CHOCOLATE)));
    public static final Item SALT_CRYSTAL = registerItem("salt_crystal", new Item(new Item.Settings()));
    public static final Item PILE_OF_SALT = registerItem("pile_of_salt", new Item(new Item.Settings()));
    public static final Item JAR_OF_PICKLES = registerItem("jar_of_pickles", new ModDrinks(new Item.Settings().food(ModDrinks.JAR_OF_PICKLES).maxCount(1)));
    public static final Item JAR_OF_PICKLED_TOMATOES = registerItem("jar_of_pickled_tomatoes", new ModDrinks(new Item.Settings().food(ModDrinks.JAR_OF_PICKLED_TOMATOES)
            .maxCount(1)));

    public static final Item COFFEE = registerItem("coffee", new ModDrinks(new Item.Settings().food(ModDrinks.COFFEE).maxCount(1)));
    public static final Item CHOCOLATE_DRINK = registerItem("chocolate_drink", new ModDrinks(new Item.Settings().food(ModDrinks.CHOCOLATE_DRINK).maxCount(1)));

    public static final Item YELLOW_CRYSTAL_SWORD = registerItem("yellow_crystal_sword", new SwordItem(ModToolsMaterials.YELLOW_CRYSTAL, new Item.Settings()
            .attributeModifiers(SwordItem.createAttributeModifiers(ModToolsMaterials.YELLOW_CRYSTAL, 8, -2.5f))));
    public static final Item YELLOW_CRYSTAL_AXE = registerItem("yellow_crystal_axe", new AxeItem(ModToolsMaterials.YELLOW_CRYSTAL, new Item.Settings()
            .attributeModifiers(AxeItem.createAttributeModifiers(ModToolsMaterials.YELLOW_CRYSTAL, 9, -2.7f))));
    public static final Item YELLOW_CRYSTAL_PICKAXE = registerItem("yellow_crystal_pickaxe", new PickaxeItem(ModToolsMaterials.YELLOW_CRYSTAL, new Item.Settings()
            .attributeModifiers(PickaxeItem.createAttributeModifiers(ModToolsMaterials.YELLOW_CRYSTAL, 2, -2.8f))));
    public static final Item YELLOW_CRYSTAL_HOE = registerItem("yellow_crystal_hoe", new HoeItem(ModToolsMaterials.YELLOW_CRYSTAL, new Item.Settings()
            .attributeModifiers(PickaxeItem.createAttributeModifiers(ModToolsMaterials.YELLOW_CRYSTAL, 2, -2.8f))));
    public static final Item YELLOW_CRYSTAL_SHOVEL = registerItem("yellow_crystal_shovel", new ShovelItem(ModToolsMaterials.YELLOW_CRYSTAL, new Item.Settings()
            .attributeModifiers(PickaxeItem.createAttributeModifiers(ModToolsMaterials.YELLOW_CRYSTAL, 3, -2.7f))));

    public static final Item YELLOW_CRYSTAL_HELMET = registerItem("yellow_crystal_helmet", new ArmorItem(ModArmorMaterials.YELLOW_CRYSTAL_ARMOR_MATERIAL,
            ArmorItem.Type.HELMET, new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(60))));
    public static final Item YELLOW_CRYSTAL_CHESTPLATE = registerItem("yellow_crystal_chestplate", new ArmorItem(ModArmorMaterials.YELLOW_CRYSTAL_ARMOR_MATERIAL,
            ArmorItem.Type.CHESTPLATE, new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(60))));
    public static final Item YELLOW_CRYSTAL_LEGGINGS = registerItem("yellow_crystal_leggings", new ArmorItem(ModArmorMaterials.YELLOW_CRYSTAL_ARMOR_MATERIAL,
            ArmorItem.Type.LEGGINGS, new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(60))));
    public static final Item YELLOW_CRYSTAL_BOOTS = registerItem("yellow_crystal_boots", new ArmorItem(ModArmorMaterials.YELLOW_CRYSTAL_ARMOR_MATERIAL,
            ArmorItem.Type.BOOTS, new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(60))));

    public static final Item YELLOW_CRYSTAL_HORSE_ARMOR = registerItem("yellow_crystal_horse_armor",
            new AnimalArmorItem(ModArmorMaterials.YELLOW_CRYSTAL_ARMOR_MATERIAL, AnimalArmorItem.Type.EQUESTRIAN, false, new Item.Settings()
                    .maxCount(1)));

    public static void registerModItems(){
        BlocksAndResources.LOGGER.info("Registering Mod Items for "+BlocksAndResources.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(YELLOW_KRYSTAL);
        });

    }
    private static Item registerItem(String name, Item item){
        return Registry.register(Registries.ITEM, Identifier.of(BlocksAndResources.MOD_ID, name), item);
    }
}
