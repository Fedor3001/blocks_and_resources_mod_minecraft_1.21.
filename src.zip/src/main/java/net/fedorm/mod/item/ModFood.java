package net.fedorm.mod.item;

import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class ModFood {
    public static final FoodComponent BROCCOLI = new FoodComponent.Builder().nutrition(4).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200), 0.25f).build();
    public static final FoodComponent TOMATO = new FoodComponent.Builder().nutrition(5).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 200), 0.5f)
            .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200),0.5f)
            .statusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200), 0.5f)
            .build();
    public static final FoodComponent CUCUMBER = new FoodComponent.Builder().nutrition(6).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200), 0.25f)
            .build();
    public static final FoodComponent SWEET_PEPER = new FoodComponent.Builder().nutrition(4).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 200), 0.1f)
            .build();
    public static final FoodComponent POMEGRANATE = new FoodComponent.Builder().nutrition(5).saturationModifier(0.25f)
            .statusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200), 0.5f).build();
    public static final FoodComponent CHOCOLATE = new FoodComponent.Builder().nutrition(8).saturationModifier(0.25f).build();

}
